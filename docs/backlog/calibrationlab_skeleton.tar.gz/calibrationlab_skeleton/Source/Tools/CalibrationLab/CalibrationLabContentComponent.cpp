#include "CalibrationLabContentComponent.h"

namespace ABD { class SynthEngine; }

namespace ABD::CalibrationLab
{
CalibrationLabContentComponent::CalibrationLabContentComponent(ABD::SynthEngine& engine)
    : synthEngine(engine)
{
    titleLabel.setText("ABDEep Calibration Lab", juce::dontSendNotification);
    titleLabel.setFont(juce::FontOptions(22.0f, juce::Font::bold));
    addAndMakeVisible(titleLabel);

    schemaLabel.setText("Schema: waiting…", juce::dontSendNotification);
    schemaLabel.setColour(juce::Label::textColourId, juce::Colours::lightgreen);
    addAndMakeVisible(schemaLabel);

    voiceLabel.setText("Voice", juce::dontSendNotification);
    addAndMakeVisible(voiceLabel);

    voiceSelector.addListener(this);
    addAndMakeVisible(voiceSelector);

    refreshButton.onClick = [this] { refreshFromSnapshot(); };
    addAndMakeVisible(refreshButton);

    configureTable();
    addAndMakeVisible(paramTable);

    detailGroup.setText("Selected Parameter Detail");
    addAndMakeVisible(detailGroup);

    detailText.setMultiLine(true);
    detailText.setReadOnly(true);
    detailText.setScrollbarsShown(true);
    detailText.setColour(juce::TextEditor::backgroundColourId, juce::Colour(0xff11161a));
    detailText.setColour(juce::TextEditor::textColourId, juce::Colours::white);
    addAndMakeVisible(detailText);

    tableModel.onSelectionChanged = [this](const ParamTraceRow* row)
    {
        updateDetailPanel(row);
    };

    updateVoiceSelector();
    tableModel.setRows(buildInitialRows());
    paramTable.updateContent();
    refreshFromSnapshot();
    startTimerHz(10);
}

CalibrationLabContentComponent::~CalibrationLabContentComponent()
{
    stopTimer();
    voiceSelector.removeListener(this);
}

void CalibrationLabContentComponent::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colour(0xff0b0f12));

    auto area = getLocalBounds().toFloat();
    g.setColour(juce::Colours::white.withAlpha(0.05f));
    g.drawRoundedRectangle(area.reduced(8.0f), 8.0f, 1.0f);
}

void CalibrationLabContentComponent::resized()
{
    auto area = getLocalBounds().reduced(12);
    auto top = area.removeFromTop(40);

    titleLabel.setBounds(top.removeFromLeft(280));
    schemaLabel.setBounds(top.removeFromLeft(180));
    voiceLabel.setBounds(top.removeFromLeft(50));
    voiceSelector.setBounds(top.removeFromLeft(140));
    refreshButton.setBounds(top.removeFromLeft(100));

    area.removeFromTop(8);
    auto detailArea = area.removeFromRight(320);

    paramTable.setBounds(area);
    detailGroup.setBounds(detailArea);
    detailText.setBounds(detailArea.reduced(12, 28));
}

void CalibrationLabContentComponent::timerCallback()
{
    refreshFromSnapshot();
}

void CalibrationLabContentComponent::comboBoxChanged(juce::ComboBox* combo)
{
    if (combo == &voiceSelector)
    {
        selectedVoiceIndex = juce::jmax(0, voiceSelector.getSelectedId() - 1);
        refreshFromSnapshot();
    }
}

void CalibrationLabContentComponent::configureTable()
{
    paramTable.setModel(&tableModel);
    auto& header = paramTable.getHeader();
    header.addColumn("Param", ParamTraceTableModel::colParam, 180, 80, 400, true);
    header.addColumn("Offset", ParamTraceTableModel::colOffset, 70, 50, 100, true);
    header.addColumn("Raw", ParamTraceTableModel::colRaw, 90, 60, 140, true);
    header.addColumn("Normalized", ParamTraceTableModel::colNormalized, 110, 80, 160, true);
    header.addColumn("DSP Base", ParamTraceTableModel::colDspBase, 110, 80, 180, true);
    header.addColumn("DSP Effective", ParamTraceTableModel::colDspEffective, 120, 80, 180, true);
    header.addColumn("Derived", ParamTraceTableModel::colDerived, 80, 60, 100, true);
    paramTable.setColour(juce::ListBox::backgroundColourId, juce::Colour(0xff101417));
    paramTable.setOutlineThickness(1);
}

void CalibrationLabContentComponent::refreshFromSnapshot()
{
    // TODO: Replace this stub with real EngineDiagnosticSnapshot / VoiceDiagnosticSnapshot plumbing.
    // Expected flow:
    // 1. Ask synthEngine for immutable diagnostic snapshot.
    // 2. Read diagnosticSchemaVersion -> schemaLabel.
    // 3. Rebuild rows for the selected voice with Raw -> Normalized -> DSP Base -> DSP Effective.
    // 4. Include modulation breakdown in detail panel for selected row.

    schemaLabel.setText("Schema: v1 (stub)", juce::dontSendNotification);

    auto rows = buildInitialRows();
    if (selectedVoiceIndex > 0)
    {
        for (auto& row : rows)
        {
            if (row.paramId == "vcfcutoff")
                row.dspEffectiveValue = "943.7 Hz";
            if (row.paramId == "vcfenvdepth")
                row.dspEffectiveValue = "+0.18";
        }
    }

    tableModel.setRows(std::move(rows));
    paramTable.updateContent();
    paramTable.repaint();
    updateDetailPanel(tableModel.getSelectedRow());
}

void CalibrationLabContentComponent::updateVoiceSelector()
{
    voiceSelector.clear(juce::dontSendNotification);

    for (int i = 0; i < 12; ++i)
        voiceSelector.addItem("Voice " + juce::String(i + 1), i + 1);

    voiceSelector.setSelectedId(selectedVoiceIndex + 1, juce::dontSendNotification);
}

void CalibrationLabContentComponent::updateDetailPanel(const ParamTraceRow* row)
{
    if (row == nullptr)
    {
        detailText.setText("No parameter selected.", juce::dontSendNotification);
        return;
    }

    juce::String text;
    text << "Param ID: " << row->paramId << "\n"
         << "Voice: " << (selectedVoiceIndex + 1) << "\n"
         << "Byte offset: " << (row->byteOffset >= 0 ? juce::String(row->byteOffset) : "-") << "\n"
         << "Raw: " << row->rawValue << "\n"
         << "Normalized: " << row->normalizedValue << "\n"
         << "DSP Base: " << row->dspBaseValue << "\n"
         << "DSP Effective: " << row->dspEffectiveValue << "\n"
         << "Derived: " << (row->derived ? "true" : "false") << "\n\n"
         << "Modulation breakdown (placeholder):\n"
         << "- Env: TODO\n"
         << "- LFO: TODO\n"
         << "- Keytracking: TODO\n"
         << "- Drift: TODO\n"
         << "- HPF / pole mode state: TODO\n";

    detailText.setText(text, juce::dontSendNotification);
}

std::vector<ParamTraceRow> CalibrationLabContentComponent::buildInitialRows() const
{
    return {
        { "vcfcutoff",      39, "191", "0.749", "821.4 Hz", "910.2 Hz", false },
        { "hpfcutoff",      40, "64",  "0.251", "118.6 Hz", "118.6 Hz", false },
        { "vcfresonance",   41, "92",  "0.361", "0.361",    "0.402",    false },
        { "vcfenvdepth",    42, "164", "+0.286", "+0.286",  "+0.331",   false },
        { "vcfkeytracking", 49, "127", "0.498", "0.498",    "0.541",    true  },
        { "vcfpolemode",    51, "1",   "2-pole", "stub/fallback", "stub/fallback", true },
        { "hpfboostenable", 52, "1",   "on",     "active",   "active",   false },
        { "voicedrift",     88, "32",  "0.125",  "0.125",    "0.161",    false }
    };
}
} // namespace ABD::CalibrationLab
