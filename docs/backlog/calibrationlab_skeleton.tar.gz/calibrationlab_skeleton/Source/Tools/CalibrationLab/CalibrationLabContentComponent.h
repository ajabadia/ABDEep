#pragma once

#include <JuceHeader.h>
#include "ParamTraceTableModel.h"

namespace ABD
{
class SynthEngine;
}

namespace ABD::CalibrationLab
{
class CalibrationLabContentComponent final : public juce::Component,
                                             private juce::Timer,
                                             private juce::ComboBox::Listener
{
public:
    explicit CalibrationLabContentComponent(ABD::SynthEngine&);
    ~CalibrationLabContentComponent() override;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void comboBoxChanged(juce::ComboBox*) override;

    void configureTable();
    void refreshFromSnapshot();
    void updateVoiceSelector();
    void updateDetailPanel(const ParamTraceRow*);
    std::vector<ParamTraceRow> buildInitialRows() const;

    ABD::SynthEngine& synthEngine;

    juce::Label titleLabel;
    juce::Label schemaLabel;
    juce::Label voiceLabel;
    juce::ComboBox voiceSelector;
    juce::TextButton refreshButton { "Refresh" };

    juce::TableListBox paramTable { "Param Trace", nullptr };
    ParamTraceTableModel tableModel;

    juce::GroupComponent detailGroup;
    juce::TextEditor detailText;

    int selectedVoiceIndex = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(CalibrationLabContentComponent)
};
} // namespace ABD::CalibrationLab
