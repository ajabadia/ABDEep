#include "ParamTraceTableModel.h"

namespace ABD::CalibrationLab
{
namespace
{
juce::String getTextForColumn(const ParamTraceRow& row, int columnId)
{
    switch (columnId)
    {
        case ParamTraceTableModel::colParam:        return row.paramId;
        case ParamTraceTableModel::colOffset:       return row.byteOffset >= 0 ? juce::String(row.byteOffset) : "-";
        case ParamTraceTableModel::colRaw:          return row.rawValue;
        case ParamTraceTableModel::colNormalized:   return row.normalizedValue;
        case ParamTraceTableModel::colDspBase:      return row.dspBaseValue;
        case ParamTraceTableModel::colDspEffective: return row.dspEffectiveValue;
        case ParamTraceTableModel::colDerived:      return row.derived ? "derived" : "";
        default:                                    return {};
    }
}
}

int ParamTraceTableModel::getNumRows()
{
    return static_cast<int>(rows.size());
}

void ParamTraceTableModel::paintRowBackground(juce::Graphics& g, int rowNumber, int width, int height,
                                              bool rowIsSelected)
{
    juce::ignoreUnused(width, height);

    if (rowIsSelected)
        g.fillAll(juce::Colour(0xff263238));
    else if (rowNumber % 2 == 0)
        g.fillAll(juce::Colour(0xff14181c));
    else
        g.fillAll(juce::Colour(0xff101417));
}

void ParamTraceTableModel::paintCell(juce::Graphics& g, int rowNumber, int columnId, int width, int height,
                                     bool rowIsSelected)
{
    juce::ignoreUnused(rowIsSelected);

    if (! juce::isPositiveAndBelow(rowNumber, static_cast<int>(rows.size())))
        return;

    const auto& row = rows[static_cast<size_t>(rowNumber)];
    g.setColour(juce::Colours::white.withAlpha(0.92f));
    g.setFont(13.0f);
    g.drawText(getTextForColumn(row, columnId), 8, 0, width - 10, height,
               juce::Justification::centredLeft, true);

    g.setColour(juce::Colours::white.withAlpha(0.08f));
    g.drawVerticalLine(width - 1, 0.0f, static_cast<float>(height));
}

void ParamTraceTableModel::selectedRowsChanged(int lastRowSelected)
{
    selectedRow = lastRowSelected;
    if (onSelectionChanged != nullptr)
        onSelectionChanged(getSelectedRow());
}

void ParamTraceTableModel::setRows(std::vector<ParamTraceRow> newRows)
{
    rows = std::move(newRows);
    if (! juce::isPositiveAndBelow(selectedRow, static_cast<int>(rows.size())))
        selectedRow = rows.empty() ? -1 : 0;
}

const ParamTraceRow* ParamTraceTableModel::getSelectedRow() const noexcept
{
    if (! juce::isPositiveAndBelow(selectedRow, static_cast<int>(rows.size())))
        return nullptr;

    return &rows[static_cast<size_t>(selectedRow)];
}
} // namespace ABD::CalibrationLab
