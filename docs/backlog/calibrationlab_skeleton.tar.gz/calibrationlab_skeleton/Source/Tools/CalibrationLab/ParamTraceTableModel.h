#pragma once

#include <JuceHeader.h>
#include <vector>

namespace ABD::CalibrationLab
{
struct ParamTraceRow
{
    juce::String paramId;
    int byteOffset = -1;
    juce::String rawValue;
    juce::String normalizedValue;
    juce::String dspBaseValue;
    juce::String dspEffectiveValue;
    bool derived = false;
};

class ParamTraceTableModel final : public juce::TableListBoxModel
{
public:
    enum ColumnId
    {
        colParam = 1,
        colOffset,
        colRaw,
        colNormalized,
        colDspBase,
        colDspEffective,
        colDerived
    };

    int getNumRows() override;

    void paintRowBackground(juce::Graphics&, int rowNumber, int width, int height,
                            bool rowIsSelected) override;
    void paintCell(juce::Graphics&, int rowNumber, int columnId, int width, int height,
                   bool rowIsSelected) override;

    void selectedRowsChanged(int lastRowSelected) override;

    void setRows(std::vector<ParamTraceRow> newRows);
    const ParamTraceRow* getSelectedRow() const noexcept;

    std::function<void(const ParamTraceRow*)> onSelectionChanged;

private:
    std::vector<ParamTraceRow> rows;
    int selectedRow = -1;
};
} // namespace ABD::CalibrationLab
